import {sumar, restar, dividir, PI} from './matematica.mjs'

console.log('La suma de 2+2=' + sumar(2, 2))
console.log('La resta de 4-1=' + restar(4, 1))
console.log('La división de 6/3=' + dividir(6, 3))
console.log('El valor de PI=' + PI)